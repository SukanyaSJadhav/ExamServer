package service;

import java.util.Set;

import com.exam.model.UserEntity;
import com.exam.model.UserRole;

public interface UserService {

	
	//Creating user
	
	public UserEntity createUser(UserEntity user, Set<UserRole> userRoles) throws Exception;
}

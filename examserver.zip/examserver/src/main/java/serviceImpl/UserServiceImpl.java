package serviceImpl;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.exam.model.UserEntity;
import com.exam.model.UserRole;

import repo.RoleRepository;
import repo.UserRepository;
import service.UserService;

public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	//Creating user
	@Override
	public UserEntity createUser(UserEntity user, Set<UserRole> userRoles) throws Exception{
		UserEntity local=this.userRepository.findByUserName(user.getUsername());
		if(local!=null)
		{
			System.out.println("User is already there!!");
			throw new Exception("User already present");
		}else {
			//create user
			for(UserRole ur:userRoles) {
				roleRepository.save(ur.getRole());
			}
			user.getUserRoles().addAll(userRoles);
			local=this.userRepository.save(user);
		}
		
			
		
		return local;
	}

}
